from app import app, db, models, admin, login_manager
from flask import render_template, redirect, url_for, flash, request, make_response
from flask_admin.contrib.sqla import ModelView
from .models import User, Product, Order, OrderItem, Review
from .forms import RegisterForm, LoginForm, AccountUpdateForm
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime
import json

admin.add_view(ModelView(User, db.session))
admin.add_view(ModelView(Product, db.session))
admin.add_view(ModelView(Order, db.session))
admin.add_view(ModelView(OrderItem, db.session))
admin.add_view(ModelView(Review, db.session))

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    return render_template('index.html', current_year=datetime.now().year)

@app.route('/products', methods=['GET'])
def products():
    # Fetch all products
    products = Product.query.all()
    products_json = []
    for product in products:
        products_json.append({
        "id": product.id,
        "name": product.name,
        "description": product.description,
        "price": product.price,
        "stock": product.stock,
    })
    return render_template('products.html', products=products_json)

@app.route('/product/<int:product_id>', methods=['GET'])
def product_detail(product_id):
    product = Product.query.get(product_id)
    if not product:
        return render_template('404.html'), 404

    reviews = Review.query.filter_by(product_id=product_id).all()

    # Fetch user details for each review
    reviews_with_user_data = [
        {
            "first_name": User.query.get(review.user_id).first_name,
            "last_name": User.query.get(review.user_id).last_name,
            "rating": review.rating,
            "comment": review.comment,
            "created_at": review.created_at
        }
        for review in reviews
    ]

    return render_template('product_detail.html', product=product, reviews=reviews_with_user_data)

@app.route('/add-review', methods=['POST'])
@login_required
def add_review():
    product_id = request.form.get('product_id')
    rating = int(request.form.get('rating'))
    comment = request.form.get('comment')

    # Ensure the product exists
    product = Product.query.get(product_id)
    if not product:
        return {"error": "Product not found"}, 404

    # Create a new review
    review = Review(
        product_id=product_id,
        user_id=current_user.id,
        rating=rating,
        comment=comment
    )
    db.session.add(review)
    db.session.commit()

    return {
        "id": review.id,
        "product_id": review.product_id,
        "first_name": current_user.first_name,
        "last_name": current_user.last_name,
        "rating": review.rating,
        "comment": review.comment,
        "created_at": review.created_at.strftime("%Y-%m-%d %H:%M:%S")
    }






@app.route('/add-to-basket', methods=['POST'])
def add_to_basket():
    # Get product ID and quantity from the form
    product_id = request.form.get('product_id')
    quantity = int(request.form.get('quantity'))

    # Retrieve the basket from cookies or initialize an empty basket
    basket_cookie = request.cookies.get('basket', '{}')
    basket = json.loads(basket_cookie)
    
    print("Basket before update:", basket)

    # Update the basket: increment quantity if product exists, otherwise add it
    if product_id in basket:
        basket[product_id] += quantity
    else:
        basket[product_id] = quantity
    
    print("Basket after update:", basket)

    # Save the updated basket to cookies
    response = make_response(redirect(url_for('basket')))
    response.set_cookie('basket', json.dumps(basket), max_age=7 * 24 * 60 * 60)  # Expires in 7 days
    return response
 

@app.route('/basket', methods=['GET'])
def basket():
    # Retrieve the basket cookie and parse it
    basket_cookie = request.cookies.get('basket', '{}')
    basket = json.loads(basket_cookie)  # Convert to Python dictionary

    # Optionally, fetch product details from the database
    products_in_basket = []
    for product_id, quantity in basket.items():
        product = Product.query.get(int(product_id))
        if product:
            products_in_basket.append({
                'id': product.id,
                'name': product.name,
                'quantity': quantity,
                'price': f"{product.price:.2f}", 
                'total_price': f"{product.price * quantity:.2f}" 
            })

    # Render the basket template
    return render_template('basket.html', products=products_in_basket)

@app.route('/update-basket', methods=['POST'])
def update_basket():
    product_id = request.json.get('product_id')
    new_quantity = request.json.get('quantity')

    # Retrieve the basket
    basket_cookie = request.cookies.get('basket', '{}')
    basket = json.loads(basket_cookie)

    # Update basket logic
    if product_id in basket:
        if new_quantity <= 0:
            basket.pop(product_id)
        else:
            basket[product_id] = new_quantity

    # Update the cookie
    response = make_response({"message": "Basket updated"})
    response.set_cookie('basket', json.dumps(basket), max_age=7 * 24 * 60 * 60)
    return response


@app.route('/delete-from-basket', methods=['POST'])
def delete_from_basket():
    product_id = request.json.get('product_id')

    # Retrieve the basket
    basket_cookie = request.cookies.get('basket', '{}')
    basket = json.loads(basket_cookie)

    # Delete the product from the basket
    if product_id in basket:
        basket.pop(product_id)

    # Update the cookie
    response = make_response({"message": "Item removed from basket"})
    response.set_cookie('basket', json.dumps(basket), max_age=7 * 24 * 60 * 60)
    return response




@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    # Fetch the basket from cookies
    basket_cookie = request.cookies.get('basket', '{}')
    basket = json.loads(basket_cookie)

    # If the basket is empty, redirect back to the basket page
    if not basket:
        flash("Your basket is empty! Add items before proceeding to checkout.")
        return redirect(url_for('basket'))

    # Fetch product details from the database
    basket_details = {}
    total_cost = 0
    for product_id, quantity in basket.items():
        product = Product.query.get(int(product_id))
        if product:
            basket_details[product_id] = {
                'name': product.name,
                'quantity': quantity,
                'price': product.price
            }
            total_cost += product.price * quantity

    # Render checkout template
    return render_template('checkout.html', basket=basket_details, total_cost=total_cost)

@app.route('/confirm-checkout', methods=['POST'])
@login_required
def confirm_checkout():
    # Retrieve the basket cookie and parse it
    basket_cookie = request.cookies.get('basket', '{}')
    basket = json.loads(basket_cookie)

    # Retrieve the submitted address
    address = request.form.get('address')

    # Validate stock availability and update stock levels
    for product_id, quantity in basket.items():
        product = Product.query.get(int(product_id))
        if not product or quantity > product.stock:
            flash(f"Product '{product.name}' is out of stock or exceeds available quantity. Please update your basket.")
            return redirect(url_for('basket'))

    # Deduct stock and create the order
    new_order = Order(user_email=current_user.email, address=address, date_ordered=datetime.now())
    db.session.add(new_order)
    db.session.flush()  # Ensure the order gets an ID
    
    for product_id, quantity in basket.items():
        product = Product.query.get(int(product_id))
        product.stock -= quantity
        order_item = OrderItem(order_id=new_order.id, product_id=product_id, quantity=quantity)
        db.session.add(order_item)

    # Commit changes to the database
    db.session.commit()

    # Clear the basket
    response = make_response(redirect(url_for('history')))
    response.set_cookie('basket', '', max_age=0)  # Clear the basket cookie
    flash("Checkout successful! Your order has been placed.")
    return response

@app.route('/history', methods=['GET'])
@login_required
def history():
    # Fetch all orders for the logged-in user
    orders = Order.query.filter_by(user_email=current_user.email).order_by(Order.date_ordered.desc()).all()
    
    # Prepare data to send to the template
    order_history = []
    for order in orders:
        # Fetch items for each order
        items = OrderItem.query.filter_by(order_id=order.id).all()
        order_items = []
        for item in items:
            product = Product.query.get(item.product_id)
            if product:
                order_items.append({
                    "name": product.name,
                    "quantity": item.quantity,
                    "price": product.price,
                    "total_price": product.price * item.quantity
                })
        order_history.append({
            "order_id": order.id,
            "date_ordered": order.date_ordered.strftime("%Y-%m-%d %H:%M:%S"),
            "address": order.address,
            "items": order_items,
            "total_value": sum(item['total_price'] for item in order_items)
        })
    
    return render_template('history.html', orders=order_history)




@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        # Check if a user with the given email exists
        if User.query.filter_by(email=form.email.data).count() != 0:
            # Fetch the user only once for password verification
            user = User.query.filter_by(email=form.email.data).first()

            # Verify password
            if check_password_hash(user.password_hash, form.password.data):
                login_user(user, remember=True)  # Log in the user with 'remember me'
                flash('Logged in successfully.')
                return redirect(url_for('index'))

        # If user doesn't exist or password is incorrect
        flash('Invalid email or password.')

    return render_template('login.html', form=form)

@app.route('/logout')
def logout():
    logout_user()  # Ends the user session
    flash('You have been logged out.')
    return redirect(url_for('index'))  # Redirect to the home page


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        # Check if email already exists
        if User.query.filter_by(email=form.email.data).count() != 0:
            flash('Email already exists. Please choose another.')
            return redirect(url_for('register'))
        
        # Create and save the new user
        hashed_password = generate_password_hash(form.password.data)
        new_user = User(
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            email=form.email.data,
            password_hash=hashed_password
        )
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please log in.')
        return redirect(url_for('login'))

    return render_template('register.html', form=form)


@app.route('/account', methods=['GET', 'POST'])
@login_required
def account():
    form = AccountUpdateForm()

    if form.validate_on_submit():
        # Validate old password only if a new password is provided
        if form.new_password.data:
            if not form.old_password.data:
                flash('Current password is required to set a new password.', 'danger')
                return redirect(url_for('account'))

            if not check_password_hash(current_user.password_hash, form.old_password.data):
                flash('Old password is incorrect.', 'danger')
                return redirect(url_for('account'))

            # Update password
            current_user.password_hash = generate_password_hash(form.new_password.data)

        # Check if email is being updated and if it already exists
        if form.email.data != current_user.email:
            existing_user = User.query.filter_by(email=form.email.data).first()
            if existing_user:
                flash('Email already exists. Please use a different email.', 'danger')
                return redirect(url_for('account'))

        # Update user's name and email
        current_user.first_name = form.first_name.data
        current_user.last_name = form.last_name.data
        current_user.email = form.email.data

        # Commit changes to the database
        db.session.commit()
        flash('Your account has been updated successfully.', 'success')
        return redirect(url_for('account'))

    # Prepopulate form fields with current user data
    if request.method == 'GET':
        form.first_name.data = current_user.first_name
        form.last_name.data = current_user.last_name
        form.email.data = current_user.email

    return render_template('account.html', form=form)


