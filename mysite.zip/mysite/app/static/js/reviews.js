$(document).ready(function () {
    $("#submit-review").on("click", function (event) {
        event.preventDefault(); // Prevent form submission

        var productId = $("input[name='product_id']").val();
        var rating = $("#rating").val();
        var comment = $("#comment").val().trim();

        // Basic validation
        if (!comment) {
            alert("Please enter a comment.");
            return;
        }

        // AJAX call to submit the review
        $.ajax({
            url: "/add-review",
            type: "POST",
            data: {
                product_id: productId,
                rating: rating,
                comment: comment
            },
            success: function (response) {
                // Clear the form fields
                $("#rating").val("1");
                $("#comment").val("");

                // Add the new review dynamically to the scrollable list
                $("#reviews-list").append(`
                    <li>
                        <strong>${response.first_name} ${response.last_name}</strong> 
                        rated <strong>${response.rating}/5</strong>
                        <p>${response.comment}</p>
                        <small>${response.created_at}</small>
                    </li>
                `);

                // Scroll to the bottom of the container
                var reviewsContainer = $("#scrollable-reviews");
                reviewsContainer.scrollTop(reviewsContainer[0].scrollHeight);
            }
        });
    });
});
