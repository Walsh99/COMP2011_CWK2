document.addEventListener("DOMContentLoaded", function () {
    // Parse the JSON data
    const products = JSON.parse(document.getElementById("product-data").textContent);
    const productsPerPage = 8;
    let currentPage = 1;

    const productContainer = document.getElementById("product-container");
    const prevPageButton = document.getElementById("prev-page");
    const nextPageButton = document.getElementById("next-page");
    const pageInfo = document.getElementById("page-info");

    // Function to render products on the page
    function renderProducts() {
        productContainer.innerHTML = "";
        var startIndex = (currentPage - 1) * productsPerPage;
        var endIndex = startIndex + productsPerPage;

        var productsToDisplay = [];
        for (var i = startIndex; i < endIndex; i++) {
            if (i < products.length) {
                productsToDisplay.push(products[i]);
            }
        }


        // Display products as cards
        for (var i = 0; i < productsToDisplay.length; i++) {
            var product = productsToDisplay[i];
            var productCard = document.createElement("div");
            productCard.classList.add("product-card");
            productCard.innerHTML = `
                <a href = "/product/${product.id}" style="text-decoration: none; color: inherit;">                
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p>Price: $${product.price.toFixed(2)}</p>
                <p style="color: ${product.stock > 0 ? 'green' : 'red'};">
                    ${product.stock > 0 ? `In Stock: ${product.stock}` : "Out of Stock"}
                </p>
            `;
            productContainer.appendChild(productCard);
        }

        // Update pagination info and button states
        pageInfo.textContent = "Page " + currentPage + " of " + Math.ceil(products.length / productsPerPage);
        // Disable the "Previous" button if on the first page
        if (currentPage <= 1) {
            prevPageButton.disabled = true;
        } else {
            prevPageButton.disabled = false;
        }

        // Disable the "Next" button if on the last page
        var totalPages = Math.floor(products.length / productsPerPage);
        if (products.length % productsPerPage !== 0) {
            totalPages++; // Add an extra page for leftover products
        }

        if (currentPage >= totalPages) {
            nextPageButton.disabled = true;
        } else {
            nextPageButton.disabled = false;
        }

    }

    prevPageButton.addEventListener("click", function () {
        if (currentPage > 1) {
            currentPage--;
            renderProducts();
        }
    });

    nextPageButton.addEventListener("click", function () {
        if (currentPage < Math.ceil(products.length / productsPerPage)) {
            currentPage++;
            renderProducts();
        }
    });

    // Initial render
    renderProducts();
});
