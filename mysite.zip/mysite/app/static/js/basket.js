$(document).ready(function () {
    // Handle quantity updates
    $(".quantity-input").on("change", function () {
        var inputElement = $(this);
        var productId = String(inputElement.data("product-id")); // Convert product_id to string
        var newQuantity = parseInt(inputElement.val());

        $.ajax({
            url: "/update-basket",
            type: "POST",
            data: JSON.stringify({ product_id: productId, quantity: newQuantity }),
            contentType: "application/json",
            dataType: "json",
            success: function (response) {
                var row = $(`tr[data-product-id="${productId}"]`);
                var price = parseFloat(row.find(".price").text().replace("£", ""));
                row.find(".total").text(`£${(price * newQuantity).toFixed(2)}`);
            },
        });
    });

    // Handle product deletion
    $(".delete-btn").on("click", function () {
        var buttonElement = $(this);
        var productId = String(buttonElement.data("product-id")); // Convert product_id to string

        $.ajax({
            url: "/delete-from-basket",
            type: "POST",
            data: JSON.stringify({ product_id: productId }),
            contentType: "application/json",
            dataType: "json",
            success: function (response) {
                var row = $(`tr[data-product-id="${productId}"]`);
                row.remove();

                if ($("tbody tr").length === 0) {
                    $(".basket-table").remove(); // Remove the table
                    $(".basket-actions").remove(); // Remove the action buttons
                    $(".empty-basket-message").removeClass("d-none"); // Show the empty basket message
                }
            },
        });
    });
});
