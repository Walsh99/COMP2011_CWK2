// 
window.addEventListener("load", function () 
{
    window.cookieconsent.initialise({
        "theme": "classic",
        "position": "middle center", 
        "content": {
            "message": "This website uses cookies to handle your shopping experience and for other necessary purposes. By continuing to use this site, you consent to the use of cookies.",
            "dismiss": "Accept",
        }
    });
});
